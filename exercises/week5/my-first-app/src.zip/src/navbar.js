import React from "react";


class NavBar extends React.Component {
  render(){
    return (
      <div className="navbar">
      <span>This is my Nav</span>
      <span className="words">about</span>
      <span className="words">something</span>
      <span className="words">rock out</span>


      </div>

    );

  }
}


export default NavBar;
