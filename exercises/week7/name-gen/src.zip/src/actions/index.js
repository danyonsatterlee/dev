export function pickName(names){
    return{
        type:"PICK_NAME",
        names: names
    }
}