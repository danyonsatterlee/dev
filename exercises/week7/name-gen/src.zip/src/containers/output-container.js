import React from 'react';

import Result from '../components/output-component.js'
class OutputCon extends React.Component{
    render(){
        return(
<div>
    <Result></Result>
</div>
        );
    }
}

export default OutputCon;